package com.example.arannyamonzur.sqliteexample;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private Button insert, display;
    private EditText editID, editName, editDept;
    private MyDatabaseHelper myDatabaseHelper;
    private SQLiteDatabase sqLiteDatabase;
    private ArrayList<String> names;
    private ArrayAdapter<String> LA;
    private ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        insert = findViewById(R.id.insert);
        display = findViewById(R.id.display);
        editID = findViewById(R.id.editID);
        editName = findViewById(R.id.editName);
        editDept = findViewById(R.id.editDept);
        listView = findViewById(R.id.listView);
        myDatabaseHelper = new MyDatabaseHelper(this);
        sqLiteDatabase = myDatabaseHelper.getWritableDatabase();
        insert.setOnClickListener(this);
        display.setOnClickListener(this);


        names = new ArrayList<String>();

        LA = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, names);

        listView.setAdapter(LA);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                /*
                String country = countries.get(i);
                Toast t = Toast.makeText(MainActivity.this, country + " clicked.",Toast.LENGTH_LONG);
                t.show();*/
                sqLiteDatabase.execSQL("Delete from " + MyDatabaseHelper.TABLE_NAME + " where "
                        + MyDatabaseHelper.col2+"='"+names.get(i)+"'");
                Toast.makeText(MainActivity.this, names.get(i) + " removed.",Toast.LENGTH_LONG).show();
                names.remove(i);
                LA.notifyDataSetChanged();
            }
        });

    }

    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.insert:
                String s1, s2, s3;
                s1 =  editID.getText().toString();
                s2 =  editName.getText().toString();
                s3 =  editDept.getText().toString();
                ContentValues cv = new ContentValues();
                cv.put("StudentID", s1);
                cv.put("StudentName", s2);
                cv.put("Department", s3);
                long rowID = sqLiteDatabase.insert(MyDatabaseHelper.TABLE_NAME, null, cv);
                if (rowID>0)
                {
                    Toast.makeText(this, "Successfully entered data", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.display:
                Cursor cursor = sqLiteDatabase.rawQuery("Select * from " + MyDatabaseHelper.TABLE_NAME,null);

                //String s="";
                while (cursor.moveToNext())
                {
                    if (!names.contains(cursor.getString(1)))
                    {
                        names.add(cursor.getString(1));
                    }
                    //s = s + ("ID: " + cursor.getString(0) +", ");
                    //s = s + ("Name: " + cursor.getString(1) +", ");
                    //s = s + ("Department: " + cursor.getString(2) +"\n");
                }
                LA.notifyDataSetChanged();
                //AlertDialog.Builder builder = new AlertDialog.Builder(this);
                //builder.setCancelable(true);
                //builder.setMessage(s);
                //builder.setTitle("Database Query");
                //builder.show();
                break;
        }
    }
}