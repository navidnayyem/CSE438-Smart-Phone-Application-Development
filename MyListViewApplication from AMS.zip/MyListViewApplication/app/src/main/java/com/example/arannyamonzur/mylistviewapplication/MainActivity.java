package com.example.arannyamonzur.mylistviewapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private TextView txtView;
    private ListView listView;
    private Button btn;
    private EditText edTxt;
    private ArrayList<String> countries;
    private ArrayAdapter<String> LA;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtView = findViewById(R.id.txtView);
        listView = findViewById(R.id.listView);
        btn = findViewById(R.id.btn);
        edTxt = findViewById(R.id.edTxt);
        btn.setOnClickListener(this);

        countries = new ArrayList<String>();

        countries.add("Bangladesh");
        countries.add("Sweden");
        countries.add("Venezuela");
        countries.add("Monaco");
        countries.add("Spain");

        LA = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, countries);

        listView.setAdapter(LA);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                /*
                String country = countries.get(i);
                Toast t = Toast.makeText(MainActivity.this, country + " clicked.",Toast.LENGTH_LONG);
                t.show();*/
                Toast.makeText(MainActivity.this, countries.get(i) + " removed.",Toast.LENGTH_LONG).show();
                countries.remove(i);
                LA.notifyDataSetChanged();
            }
        });
    }

    @Override
    public void onClick(View view) {
        String country = edTxt.getText().toString();
        countries.add(country);
        LA.notifyDataSetChanged();
    }
}