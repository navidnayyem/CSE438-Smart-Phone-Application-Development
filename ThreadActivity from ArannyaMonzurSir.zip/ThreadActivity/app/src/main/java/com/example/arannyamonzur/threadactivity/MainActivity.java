package com.example.arannyamonzur.threadactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;

import java.util.Random;
import java.util.concurrent.Executor;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private Button btn;
    private ProgressBar pgsBar1;
    private ProgressBar pgsBar2;
    private int i=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn = findViewById(R.id.btn);
        pgsBar1 = findViewById(R.id.pgsBar1);
        pgsBar2 = findViewById(R.id.pgsBar2);
        btn.setOnClickListener(this);
    }



    private class AsyncExample extends AsyncTask<ProgressBar,Integer,Void>
    {
        ProgressBar pb;
        @Override
        protected Void doInBackground(ProgressBar... progress) {
            pb = progress[0];
            Random r = new Random();
            int rand = r.nextInt(500);
            for (int i=1;i<=100;i++)
            {
                publishProgress(i);
                try{
                    Thread.sleep(rand);
                }
                catch(InterruptedException e)
                {
                    ;
                }
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(Integer... updates)
        {
            pb.setProgress(updates[0]);
        }
    }
    @Override
    public void onClick(View view) {
        new AsyncExample().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR,pgsBar1);
        new AsyncExample().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR,pgsBar2);
    }
}