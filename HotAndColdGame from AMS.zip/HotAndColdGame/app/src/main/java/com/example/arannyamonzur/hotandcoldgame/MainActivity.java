package com.example.arannyamonzur.hotandcoldgame;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private TextView txtView;
    private EditText edTxt;
    private Button btn;
    private Random random;
    private int guess;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtView = findViewById(R.id.txtView);
        edTxt = findViewById(R.id.edTxt);
        btn = findViewById(R.id.btn);
        btn.setOnClickListener(this);
        random = new Random();
        guess = random.nextInt(100);
    }

    @Override
    public void onClick(View view) {
        String s = edTxt.getText().toString();
        int value = Integer.parseInt(s);
        if (value>100)
        {
            Toast.makeText(this,"Your guess was greater than the expected range", Toast.LENGTH_SHORT).show();
        }
        else if (value<0)
        {
            Toast.makeText(this,"Your guess was smaller than the expected range", Toast.LENGTH_SHORT).show();
        }
        else if (value>guess)
        {
            Toast.makeText(this,"Your guess was greater than the required number.", Toast.LENGTH_SHORT).show();
        }
        else if (value<guess)
        {
            Toast.makeText(this,"Your guess was smaller than the required number", Toast.LENGTH_SHORT).show();
        }
        else if (value==guess)
        {
            Toast.makeText(this,"Your guess was correct!", Toast.LENGTH_SHORT).show();
        }
    }
}