package com.example.arannyamonzur.fragmentexample;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private Button button1, button2;
    private FragmentOne f1;
    private FragmentTwo f2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button1 = findViewById(R.id.button1);
        button2 = findViewById(R.id.button2);
        button1.setOnClickListener(this);
        button2.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        if (view.getId()==R.id.button1)
        {
            f1 = new FragmentOne();
            ft.replace(R.id.anchor1,f1);
            ft.commit();
        }
        else if (view.getId()==R.id.button2)
        {
            f2= new FragmentTwo();
            ft.replace(R.id.anchor2,f2);
            ft.commit();
        }
    }
    void setText(String input)
    {
        f2.setText(input);
    }
}