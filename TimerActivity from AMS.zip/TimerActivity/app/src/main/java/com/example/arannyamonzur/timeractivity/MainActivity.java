package com.example.arannyamonzur.timeractivity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private TextView tv1,tv2;
    private Button btn;
    private Timer t1,t2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv1 = findViewById(R.id.tv1);
        tv2 = findViewById(R.id.tv2);
        btn = findViewById(R.id.btn);
        btn.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        t1 = new Timer();
        t2 = new Timer();
        TimerTask tt1 = new TimerTask() {
            public int i = 0;

            @Override
            public void run() {
                i = i + 1;
                tv1.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        tv1.setText(i + "");
                    }
                }, 0);
                if (i==50) {
                    t2.cancel();
                }
                if (i==60)
                {
                    t1.cancel();
                }
            }
        };
        TimerTask tt2 = new TimerTask() {
                public int i = 0;

                @Override
                public void run() {
                    i = i + 1;
                    tv2.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            tv2.setText(i + "");
                        }
                    }, 0);
                }
        };
        t1.schedule(tt1,0,500);
        t2.schedule(tt2,0,1000);
    }
}