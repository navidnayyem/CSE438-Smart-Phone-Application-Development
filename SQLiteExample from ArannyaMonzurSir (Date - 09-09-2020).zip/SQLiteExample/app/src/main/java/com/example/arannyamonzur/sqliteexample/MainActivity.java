package com.example.arannyamonzur.sqliteexample;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private Button insert, display;
    private EditText editID, editName, editDept;
    private MyDatabaseHelper myDatabaseHelper;
    private SQLiteDatabase sqLiteDatabase;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        insert = findViewById(R.id.insert);
        display = findViewById(R.id.display);
        editID = findViewById(R.id.editID);
        editName = findViewById(R.id.editName);
        editDept = findViewById(R.id.editDept);
        myDatabaseHelper = new MyDatabaseHelper(this);
        sqLiteDatabase = myDatabaseHelper.getWritableDatabase();
        insert.setOnClickListener(this);
        display.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.insert:
                String s1, s2, s3;
                s1 =  editID.getText().toString();
                s2 =  editName.getText().toString();
                s3 =  editDept.getText().toString();
                ContentValues cv = new ContentValues();
                cv.put("StudentID", s1);
                cv.put("StudentName", s2);
                cv.put("Department", s3);
                long rowID = sqLiteDatabase.insert(MyDatabaseHelper.TABLE_NAME, null, cv);
                if (rowID>0)
                {
                    Toast.makeText(this, "Successfully entered data", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.display:
                Cursor cursor = sqLiteDatabase.rawQuery("Select * from " + MyDatabaseHelper.TABLE_NAME,null);
                String s="";
                while (cursor.moveToNext())
                {
                    s = s + ("ID: " + cursor.getString(0) +", ");
                    s = s + ("Name: " + cursor.getString(1) +", ");
                    s = s + ("Department: " + cursor.getString(2) +"\n");
                }
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setCancelable(true);
                builder.setMessage(s);
                builder.setTitle("Database Query");
                builder.show();
                break;
        }
    }
}