package com.example.arannyamonzur.sqliteexample;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class MyDatabaseHelper extends SQLiteOpenHelper {
    public static final String DB_NAME = "ulab.db";
    public static final int DB_VERSION = 1;
    public static final String TABLE_NAME = "Students";
    public static final String col1 = "StudentID";
    public static final String col2 = "StudentName";
    public static final String col3 = "Department";
    public static final String CREATE_TABLE
            = "create table " + TABLE_NAME +"("
            + col1 + " integer primary key, "
            + col2 + " varchar2, "
            + col3 + " varchar2)";
    public static final String DROP_TABLE = "drop table" + TABLE_NAME;
    private Context context;
    public MyDatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        try {
            sqLiteDatabase.execSQL(CREATE_TABLE);
            Toast.makeText(context, "Database successfully created.", Toast.LENGTH_SHORT).show();
        }
        catch (Exception e) {
            Toast.makeText(context, "Database creation failed.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        try{
            sqLiteDatabase.execSQL(DROP_TABLE);
            onCreate(sqLiteDatabase);
        }
        catch (Exception e) {
            Toast.makeText(context, "Database update failed.", Toast.LENGTH_SHORT).show();
        }
    }
}
