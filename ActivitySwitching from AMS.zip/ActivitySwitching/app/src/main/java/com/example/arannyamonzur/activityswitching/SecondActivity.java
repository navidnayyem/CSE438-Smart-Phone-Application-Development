package com.example.arannyamonzur.activityswitching;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        //Toast t = Toast.makeText(this, "Second Activity started!", Toast.LENGTH_SHORT);
        //t.show();
        Intent intent = getIntent();
        String s2 = intent.getStringExtra("key");
        Toast.makeText(this, "Hello, " + s2+"!", Toast.LENGTH_SHORT).show();
    }
}