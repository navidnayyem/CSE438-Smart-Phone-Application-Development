package com.example.arannyamonzur.linearlayoutexample;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private Button b0, b1, b2, b3, b4, b5, b6, b7, b8, b9;
    private Button bplus, bminus, bmul, bdiv, beq;
    private TextView txtView;
    private int temp=0;
    private int choice=-1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b0 = findViewById(R.id.b0);
        b1 = findViewById(R.id.b1);
        b2 = findViewById(R.id.b2);
        b3 = findViewById(R.id.b3);
        b4 = findViewById(R.id.b4);
        b5 = findViewById(R.id.b5);
        b6 = findViewById(R.id.b6);
        b7 = findViewById(R.id.b7);
        b8 = findViewById(R.id.b8);
        b9 = findViewById(R.id.b9);

        bplus = findViewById(R.id.bplus);
        bminus = findViewById(R.id.bminus);
        bmul = findViewById(R.id.bmul);
        bdiv = findViewById(R.id.bdiv);
        beq = findViewById(R.id.beq);

        b0.setOnClickListener(this);
        b1.setOnClickListener(this);
        b2.setOnClickListener(this);
        b3.setOnClickListener(this);
        b4.setOnClickListener(this);
        b5.setOnClickListener(this);
        b6.setOnClickListener(this);
        b7.setOnClickListener(this);
        b8.setOnClickListener(this);
        b9.setOnClickListener(this);

        bplus.setOnClickListener(this);
        bminus.setOnClickListener(this);
        bmul.setOnClickListener(this);
        bdiv.setOnClickListener(this);
        beq.setOnClickListener(this);


        txtView = findViewById(R.id.txtView);
    }

    @Override
    public void onClick(View view) {
        String s1;
        switch(view.getId())
        {
            case R.id.b0:
                s1 = txtView.getText().toString();
                s1 = s1 + "0";
                txtView.setText(s1);
                break;
            case R.id.b1:
                s1 = txtView.getText().toString();
                s1 = s1 + "1";
                txtView.setText(s1);
                break;
            case R.id.b2:
                s1 = txtView.getText().toString();
                s1 = s1 + "2";
                txtView.setText(s1);
                break;
            case R.id.b3:
                s1 = txtView.getText().toString();
                s1 = s1 + "3";
                txtView.setText(s1);
                break;
            case R.id.b4:
                s1 = txtView.getText().toString();
                s1 = s1 + "4";
                txtView.setText(s1);
                break;
            case R.id.b5:
                s1 = txtView.getText().toString();
                s1 = s1 + "5";
                txtView.setText(s1);
                break;
            case R.id.b6:
                s1 = txtView.getText().toString();
                s1 = s1 + "6";
                txtView.setText(s1);
                break;
            case R.id.b7:
                s1 = txtView.getText().toString();
                s1 = s1 + "7";
                txtView.setText(s1);
                break;
            case R.id.b8:
                s1 = txtView.getText().toString();
                s1 = s1 + "8";
                txtView.setText(s1);
                break;
            case R.id.b9:
                s1 = txtView.getText().toString();
                s1 = s1 + "9";
                txtView.setText(s1);
                break;
            case R.id.bplus:
                temp = Integer.parseInt(txtView.getText().toString());
                choice=0;
                txtView.setText("");
                break;
            case R.id.bminus:
                temp = Integer.parseInt(txtView.getText().toString());
                choice=1;
                txtView.setText("");
                break;
            case R.id.bmul:
                temp = Integer.parseInt(txtView.getText().toString());
                choice=2;
                txtView.setText("");
                break;
            case R.id.bdiv:
                temp = Integer.parseInt(txtView.getText().toString());
                choice=3;
                txtView.setText("");
                break;
            case R.id.beq:
                int result=0;
                double div_result=0;
                //Toast.makeText(this, "temp_value:"+temp, Toast.LENGTH_SHORT).show();
                if (choice == 0)
                {
                    int temp2 = Integer.parseInt(txtView.getText().toString());
                    result = temp + temp2;
                }
                else if (choice==1)
                {
                    int temp2 = Integer.parseInt(txtView.getText().toString());
                    result = temp - temp2;
                }
                else if (choice==2)
                {
                    int temp2 = Integer.parseInt(txtView.getText().toString());
                    result = temp * temp2;
                }
                else if (choice==3)
                {
                    int temp2 = Integer.parseInt(txtView.getText().toString());
                    div_result = (double) temp / temp2;
                }
                if (choice>=0 && choice<3) txtView.setText(result+"");
                else if (choice == 3) txtView.setText(div_result+"");
                break;
        }
    }
}